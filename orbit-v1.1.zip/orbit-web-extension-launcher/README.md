# Orbit — Mobile Web Launcher

A minimal mobile-first website launcher and lightweight custom-extension prototype.

## Upload the project using one ZIP file

1. In your GitHub repository, create `.github/workflows/build-apk.yml` first and paste the workflow from this project (the workflow file is also included in this ZIP).
2. Upload this entire ZIP file to the repository root. Do not extract it on your phone.
3. Open **Actions** and run **Build Orbit APK**. The workflow extracts the ZIP, installs dependencies, and builds the APK.
4. Download the `orbit-debug-apk` artifact from the completed workflow run, extract it, and install `app-debug.apk`.

**Important:** GitHub cannot run a workflow that exists only inside an uploaded ZIP. The workflow must be present in `.github/workflows/build-apk.yml` in the repository before the first run. After that, the project itself can be uploaded as one ZIP file.

## Important limitations

- This is a web launcher packaged with Capacitor, not a full Chrome replacement.
- Some websites block iframe embedding and will not display inside Orbit; use the external-open option.
- Custom JavaScript extensions can be saved/imported and manually run where browser same-origin rules allow.
- Basic `.user.js` files are imported as JavaScript only; there is no full Tampermonkey metadata/matching engine.
- Chrome `.crx` packages and the full Chrome Manifest V3 API are not supported.
- Only import and run code you trust.

## v1.1 changes

- Links now open in the system browser (Chrome Custom Tab), so Google, YouTube and GitHub work.
- New **Get source** tab: paste a Chrome Web Store, Edge Add-ons or Firefox Add-ons link (or extension ID) and share the source as a .zip.
- Fixed regex typos (import names, URL detection).
- Extensions can no longer run "on" live sites (no in-app frame); they are saved/edited only.
